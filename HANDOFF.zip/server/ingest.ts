import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import AdmZip from 'adm-zip';
import { appendLedgerEntry } from './ledger.js';

export interface IngestResult {
  workspaceHash: string;
  fileCount: number;
  totalSize: number;
  sourceType: 'github' | 'zip';
  sourceUrl?: string;
  files: Array<{ relPath: string; size: number; sha256: string }>;
}

const WORKSPACES_DIR = path.resolve(process.cwd(), 'data', 'workspaces');

function ensureWorkspacesDir() {
  if (!fs.existsSync(WORKSPACES_DIR)) {
    fs.mkdirSync(WORKSPACES_DIR, { recursive: true });
  }
}

/**
 * 校验路径安全性，防止 Path Traversal 注入攻击
 */
export function sanitizePath(baseDir: string, relativePath: string): string {
  const normalized = path.normalize(relativePath).replace(/^(\.\.[\/\\])+/, '');
  const resolved = path.resolve(baseDir, normalized);
  if (!resolved.startsWith(baseDir)) {
    throw new Error(`非法路径遍历风险: ${relativePath}`);
  }
  return resolved;
}

/**
 * 将 Zip Buffer 解压并存储在隔离的项目空间目录中
 */
export function processZipBuffer(
  buffer: Buffer,
  sourceType: 'github' | 'zip',
  sourceUrl?: string
): IngestResult {
  ensureWorkspacesDir();

  if (buffer.length > 100 * 1024 * 1024) {
    throw new Error('压缩包文件过大，超出 100MB 限制');
  }

  const zip = new AdmZip(buffer);
  const zipEntries = zip.getEntries();

  if (zipEntries.length > 5000) {
    throw new Error('解压文件数超出 5000 个上限');
  }

  // 计算整体 Buffer 的 SHA256 作为唯一 workspaceHash
  const workspaceHash = crypto.createHash('sha256').update(buffer).digest('hex');
  const workspaceDir = path.join(WORKSPACES_DIR, workspaceHash);

  // 若已存在，先清理旧文件重新解压
  if (fs.existsSync(workspaceDir)) {
    fs.rmSync(workspaceDir, { recursive: true, force: true });
  }
  fs.mkdirSync(workspaceDir, { recursive: true });

  // 检查是否包含单一顶级目录包装（例如 GitHub 自动打包的 repo-main/ 目录）
  const validEntries = zipEntries.filter((e) => !e.isDirectory);
  const firstLevelDirs = new Set<string>();
  for (const entry of zipEntries) {
    const parts = entry.entryName.split('/').filter(Boolean);
    if (parts.length > 0) {
      firstLevelDirs.add(parts[0]);
    }
  }

  const hasSingleTopDir =
    firstLevelDirs.size === 1 &&
    zipEntries.every((e) => e.entryName.startsWith(Array.from(firstLevelDirs)[0] + '/'));

  const topDirName = hasSingleTopDir ? Array.from(firstLevelDirs)[0] + '/' : '';

  let fileCount = 0;
  let totalSize = 0;
  const filesMeta: Array<{ relPath: string; size: number; sha256: string }> = [];

  for (const entry of zipEntries) {
    if (entry.isDirectory) continue;

    let relPath = entry.entryName;
    if (hasSingleTopDir && relPath.startsWith(topDirName)) {
      relPath = relPath.slice(topDirName.length);
    }

    // 过滤不合法或隐藏系统垃圾文件（如 .git、__MACOSX、.DS_Store）
    if (
      relPath.startsWith('.git/') ||
      relPath.startsWith('__MACOSX/') ||
      relPath.endsWith('.DS_Store')
    ) {
      continue;
    }

    const targetPath = sanitizePath(workspaceDir, relPath);
    const targetFolder = path.dirname(targetPath);
    if (!fs.existsSync(targetFolder)) {
      fs.mkdirSync(targetFolder, { recursive: true });
    }

    const contentBuffer = entry.getData();
    fs.writeFileSync(targetPath, contentBuffer);

    const size = contentBuffer.length;
    const sha256 = crypto.createHash('sha256').update(contentBuffer).digest('hex');

    fileCount++;
    totalSize += size;
    filesMeta.push({ relPath, size, sha256 });
  }

  // 写入原始元数据文件 meta.json 到 workspace
  const metaObj = {
    workspaceHash,
    ingestTime: new Date().toISOString(),
    sourceType,
    sourceUrl: sourceUrl || '',
    fileCount,
    totalSize,
  };
  fs.writeFileSync(
    path.join(workspaceDir, '.ingest_meta.json'),
    JSON.stringify(metaObj, null, 2),
    'utf-8'
  );

  // 写入证据账本 (Append-only)
  appendLedgerEntry({
    stage: 'STAGE1',
    action: 'INGEST_PROJECT',
    inputs_hash: crypto.createHash('sha256').update(sourceUrl || buffer).digest('hex'),
    outputs_hash: workspaceHash,
    ref: {
      workspace_hash: workspaceHash,
      details: `导入项目成功: ${sourceType === 'github' ? sourceUrl : 'Zip 上传'} (${fileCount} 个文件, ${totalSize} 字节)`,
    },
  });

  return {
    workspaceHash,
    fileCount,
    totalSize,
    sourceType,
    sourceUrl,
    files: filesMeta,
  };
}

/**
 * 从 GitHub 公开仓库下载 zip 归档包并解压
 */
export async function ingestGithubRepo(repoUrl: string): Promise<IngestResult> {
  const parsed = parseGithubUrl(repoUrl);
  if (!parsed) {
    throw new Error('无法解析有效的 GitHub 仓库地址，请检查格式');
  }

  const { owner, repo, ref } = parsed;

  // 优先尝试 zipball API
  const zipApiUrl = `https://api.github.com/repos/${owner}/${repo}/zipball/${ref || ''}`;

  const headers: Record<string, string> = {
    'User-Agent': 'AI-Studio-Applet-IngestEngine',
    Accept: 'application/vnd.github.v3+json',
  };

  if (process.env.GITHUB_TOKEN) {
    headers['Authorization'] = `Bearer ${process.env.GITHUB_TOKEN}`;
  }

  const response = await fetch(zipApiUrl, {
    headers,
    redirect: 'follow',
  });

  if (!response.ok) {
    if (response.status === 404) {
      throw new Error(`GitHub 仓库 ${owner}/${repo} 不存在或不可访问 (404)`);
    }
    throw new Error(`下载 GitHub 仓库失败: ${response.status} ${response.statusText}`);
  }

  const arrayBuffer = await response.arrayBuffer();
  const buffer = Buffer.from(arrayBuffer);

  return processZipBuffer(buffer, 'github', repoUrl);
}

/**
 * 解析 GitHub 仓库 URL
 */
function parseGithubUrl(urlStr: string): { owner: string; repo: string; ref?: string } | null {
  try {
    let clean = urlStr.trim();
    if (!clean.startsWith('http://') && !clean.startsWith('https://')) {
      clean = 'https://github.com/' + clean;
    }

    const url = new URL(clean);
    if (!url.hostname.includes('github.com')) {
      return null;
    }

    const parts = url.pathname.split('/').filter(Boolean);
    if (parts.length < 2) return null;

    const owner = parts[0];
    const repo = parts[1].replace(/\.git$/, '');
    let ref: string | undefined = undefined;

    if (parts[2] === 'tree' && parts[3]) {
      ref = parts.slice(3).join('/');
    }

    return { owner, repo, ref };
  } catch {
    return null;
  }
}
