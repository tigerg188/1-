import React, { useState, useEffect } from 'react';
import { ExecutionState } from '../types';
import {
  Play,
  RefreshCw,
  Terminal,
  Cpu,
  CheckCircle2,
  AlertTriangle,
  FileCode,
  Download,
} from 'lucide-react';

interface ExecutePageProps {
  workspaceHash: string | null;
  onModelCallTriggered?: () => void;
}

export const ExecutePage: React.FC<ExecutePageProps> = ({
  workspaceHash,
  onModelCallTriggered,
}) => {
  const [taskText, setTaskText] = useState('分析并运行当前 Agent/Skill 模块，验证解耦独立性');
  const [testMode, setTestMode] = useState(true);
  const [tokenBudget, setTokenBudget] = useState(10000);
  const [execState, setExecState] = useState<ExecutionState | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchStatus = async () => {
    if (!workspaceHash) return;
    try {
      const { safeFetchJson } = await import('../utils/safeFetch');
      const data = await safeFetchJson(`/api/execute/status/${workspaceHash}`);
      if (data.success && data.data) {
        setExecState(data.data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchStatus();
  }, [workspaceHash]);

  const handleStartTask = async () => {
    if (!workspaceHash || !taskText.trim()) return;
    setRunning(true);
    setError(null);
    try {
      const { safeFetchJson } = await import('../utils/safeFetch');
      const data = await safeFetchJson('/api/execute/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workspaceHash,
          taskText: taskText.trim(),
          testMode,
          tokenBudget,
        }),
      });
      if (!data.success) throw new Error(data.error || '启动任务失败');
      setExecState(data.data);
      if (onModelCallTriggered) onModelCallTriggered();
    } catch (err: any) {
      setError(err.message || '执行过程出现异常');
    } finally {
      setRunning(false);
    }
  };

  const handleContinueTask = async () => {
    if (!workspaceHash) return;
    setRunning(true);
    setError(null);
    try {
      const { safeFetchJson } = await import('../utils/safeFetch');
      const data = await safeFetchJson('/api/execute/continue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workspaceHash }),
      });
      if (!data.success) throw new Error(data.error || '继续运行失败');
      setExecState(data.data);
      if (onModelCallTriggered) onModelCallTriggered();
    } catch (err: any) {
      setError(err.message || '继续运行出现异常');
    } finally {
      setRunning(false);
    }
  };

  if (!workspaceHash) {
    return (
      <div className="max-w-4xl mx-auto py-12 text-center space-y-4">
        <Terminal className="w-12 h-12 text-slate-600 mx-auto" />
        <h2 className="text-lg font-semibold text-slate-300">暂无载入的工作空间</h2>
        <p className="text-xs text-slate-500">请先在“导入”页面导入一个项目空间。</p>
      </div>
    );
  }

  const budgetPercentage = execState
    ? Math.min(100, Math.round((execState.tokensUsed / execState.tokenBudget) * 100))
    : 0;

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* 标题栏 */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
            <Terminal className="w-6 h-6 text-sky-400" />
            用户任务适配运行引擎 (Task Execution Engine)
          </h1>
          <p className="text-slate-400 text-xs mt-1">
            由 Stage 3 选定的后端/适配器驱动运行，实打点审计，支持断点恢复与 429 额度避退
          </p>
        </div>

        <div className="flex items-center gap-3">
          {execState?.status === 'paused_quota' || execState?.status === 'incomplete' ? (
            <button
              onClick={handleContinueTask}
              disabled={running}
              className="px-5 py-2.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-medium text-xs rounded-xl transition-colors flex items-center gap-2 shadow-lg shadow-amber-950"
            >
              <RefreshCw className={`w-4 h-4 ${running ? 'animate-spin' : ''}`} />
              <span>继续运行保存的进度</span>
            </button>
          ) : (
            <button
              onClick={handleStartTask}
              disabled={running || !taskText.trim()}
              className="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white font-medium text-xs rounded-xl transition-colors flex items-center gap-2 shadow-lg shadow-sky-950"
            >
              {running ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Play className="w-4 h-4 fill-white" />
              )}
              <span>{running ? '正在调度后端执行...' : '启动 / 恢复任务运行'}</span>
            </button>
          )}
        </div>
      </div>

      {error && <div className="p-4 bg-rose-950 text-rose-300 text-xs rounded-xl">{error}</div>}

      {/* 额度用完中断警告横幅 (遵从 429 规格) */}
      {execState?.status === 'paused_quota' && (
        <div className="p-4 bg-amber-950/80 border border-amber-500/60 rounded-xl flex items-center justify-between gap-4 text-amber-200 text-xs">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />
            <div className="font-semibold">额度已用完，进度已保存，可稍后继续</div>
          </div>
          <button
            onClick={handleContinueTask}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-lg font-bold shrink-0"
          >
            继续重试
          </button>
        </div>
      )}

      {/* 任务输入与配置面板 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* 任务输入框 */}
        <div className="md:col-span-2 bg-slate-800/60 border border-slate-700/60 rounded-xl p-5 space-y-3">
          <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
            <span>用户输入任务描述 (Task Input - Runtime Only)</span>
            <span className="text-[11px] text-slate-500 font-mono">运行时自由文本</span>
          </label>
          <textarea
            value={taskText}
            onChange={(e) => setTaskText(e.target.value)}
            disabled={running}
            rows={4}
            placeholder="在此输入自定义用户运行任务描述..."
            className="w-full p-3 bg-slate-900 border border-slate-700 rounded-lg text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono"
          />
        </div>

        {/* 运行参数与实时 Token 仪表 */}
        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-5 space-y-4 font-mono text-xs">
          <h3 className="font-semibold text-slate-200 font-sans flex items-center gap-1.5">
            <Cpu className="w-4 h-4 text-sky-400" />
            <span>运行参数与 Token 预算</span>
          </h3>

          <div className="flex items-center justify-between p-3 bg-slate-900 rounded-lg border border-slate-800">
            <span className="text-slate-300 font-sans">测试模式 (Test Mode)</span>
            <button
              onClick={() => setTestMode(!testMode)}
              className={`px-2.5 py-1 rounded text-[11px] font-bold ${
                testMode
                  ? 'bg-emerald-950 border border-emerald-800 text-emerald-400'
                  : 'bg-slate-800 text-slate-400'
              }`}
            >
              {testMode ? '已开启 (缩减范围)' : '关闭'}
            </button>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-slate-400 font-sans">
              <span>Token 预算上限</span>
              <span>{tokenBudget} Tokens</span>
            </div>
            <input
              type="range"
              min={2000}
              max={50000}
              step={1000}
              value={tokenBudget}
              onChange={(e) => setTokenBudget(Number(e.target.value))}
              className="w-full accent-sky-500"
            />
          </div>

          {/* 实时 Token 使用指示条 */}
          {execState && (
            <div className="space-y-1.5 pt-2 border-t border-slate-800">
              <div className="flex justify-between text-[11px]">
                <span className="text-slate-400 font-sans">实时使用进度</span>
                <span className="text-sky-400 font-bold">
                  {execState.tokensUsed} / {execState.tokenBudget} ({budgetPercentage}%)
                </span>
              </div>
              <div className="w-full bg-slate-900 h-2 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="bg-sky-500 h-full transition-all duration-300"
                  style={{ width: `${budgetPercentage}%` }}
                />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 实时执行终端 Live Stream Terminal */}
      {execState && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 font-mono text-xs">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span className="font-bold text-slate-200">执行步骤实时打卡记录 (Live Ledger Steps)</span>
            </div>
            <span
              className={`px-2.5 py-0.5 rounded text-[11px] font-bold ${
                execState.status === 'completed'
                  ? 'bg-emerald-950 border border-emerald-800 text-emerald-400'
                  : execState.status === 'paused_quota'
                  ? 'bg-amber-950 border border-amber-800 text-amber-400'
                  : 'bg-sky-950 border border-sky-800 text-sky-400'
              }`}
            >
              Status: {execState.status}
            </span>
          </div>

          <div className="space-y-2.5 font-mono text-xs max-h-96 overflow-y-auto">
            {execState.steps.map((st) => (
              <div key={st.stepIndex} className="p-3 bg-slate-950 border border-slate-800/80 rounded-lg space-y-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <div className="flex items-center gap-2">
                    <span className="px-1.5 py-0.5 bg-slate-800 text-sky-400 rounded">
                      Step #{st.stepIndex}
                    </span>
                    <span className="text-slate-200 uppercase font-bold">{st.stepType}</span>
                  </div>
                  <span className="text-slate-500">{new Date(st.timestamp).toLocaleTimeString()}</span>
                </div>

                <div className="text-slate-300 font-sans text-xs bg-slate-900/90 p-2 rounded border border-slate-800">
                  {st.truncatedInputOutput}
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1">
                  <span>Full Hash: {st.fullContentHash.slice(0, 16)}...</span>
                  <span>Tokens: {st.tokensUsed}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 产出交付物列表 (Artifacts with SHA256) */}
      {execState && execState.artifacts.length > 0 && (
        <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-5 space-y-3 font-mono text-xs">
          <h3 className="font-semibold text-slate-200 font-sans flex items-center gap-2">
            <FileCode className="w-4 h-4 text-emerald-400" />
            <span>收集的产出交付物 (Artifacts & Hash Registry)</span>
          </h3>

          <div className="space-y-2">
            {execState.artifacts.map((art) => (
              <div key={art.fileName} className="p-3 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div>
                    <div className="text-slate-200 font-bold">{art.fileName}</div>
                    <div className="text-[11px] text-slate-500">SHA256: {art.sha256}</div>
                  </div>
                </div>

                <div className="text-slate-400 text-right">
                  <div>{art.size} B</div>
                  <div className="text-[10px] text-slate-500">{new Date(art.createdAt).toLocaleTimeString()}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
