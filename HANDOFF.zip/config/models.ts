/**
 * 统一模型与 Agent 配置文件
 * 严格遵从 C6 (Quota-Friendly): 所有模型与 Agent ID 仅在本文件中配置，禁止出现在逻辑代码中
 */

export interface ModelConfig {
  id: string;
  name: string;
  provider: string;
  temperature: number;
  maxOutputTokens: number;
}

export const SYSTEM_MODELS: Record<string, ModelConfig> = {
  DEFAULT_UNDERSTANDING: {
    id: "gemini-2.5-flash",
    name: "Gemini 2.5 Flash",
    provider: "google",
    temperature: 0.1,
    maxOutputTokens: 8192,
  },
  DEFAULT_FEASIBILITY: {
    id: "gemini-2.5-flash",
    name: "Gemini 2.5 Flash",
    provider: "google",
    temperature: 0.2,
    maxOutputTokens: 8192,
  },
  DEFAULT_EXECUTION: {
    id: "gemini-2.5-flash",
    name: "Gemini 2.5 Flash",
    provider: "google",
    temperature: 0.3,
    maxOutputTokens: 8192,
  },
};

export const AGENT_REGISTRY = {
  UNDERSTAND_AGENT: {
    modelId: SYSTEM_MODELS.DEFAULT_UNDERSTANDING.id,
    role: "Blueprint Analysis Agent",
  },
  FEASIBILITY_AGENT: {
    modelId: SYSTEM_MODELS.DEFAULT_FEASIBILITY.id,
    role: "Portability Evaluation Agent",
  },
  EXECUTION_AGENT: {
    modelId: SYSTEM_MODELS.DEFAULT_EXECUTION.id,
    role: "Adapter Execution Agent",
  },
  VERIFY_AGENT: {
    modelId: SYSTEM_MODELS.DEFAULT_EXECUTION.id,
    role: "Verification Agent",
  },
};
