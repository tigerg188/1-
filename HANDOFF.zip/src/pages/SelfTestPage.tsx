import React, { useState } from 'react';
import { SelfTestResult } from '../types';
import { CheckCircle2, XCircle, Play, ShieldCheck, FileSearch, RefreshCw, AlertTriangle } from 'lucide-react';

interface SelfTestPageProps {
  workspaceHash: string | null;
}

export const SelfTestPage: React.FC<SelfTestPageProps> = ({ workspaceHash }) => {
  const [result, setResult] = useState<SelfTestResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleRunSelfTest = async () => {
    setLoading(true);
    setError(null);
    try {
      const { safeFetchJson } = await import('../utils/safeFetch');
      const data = await safeFetchJson('/api/selftest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workspaceHash }),
      });
      if (!data.success) throw new Error(data.error || '自检失败');
      setResult(data.data);
    } catch (err: any) {
      setError(err.message || '触发自检遇到错误');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* 标题栏 */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-sky-400" />
            系统确定性自检 (Self-Test Suite)
          </h1>
          <p className="text-slate-400 text-xs mt-1">
            纯代码自动化检验：违禁词审查 (C1/C2) · 清单确定性对比 (C5) · 证据账本完整性 (C4/C8)
          </p>
        </div>

        <button
          onClick={handleRunSelfTest}
          disabled={loading}
          className="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white font-medium text-xs rounded-xl transition-colors flex items-center gap-2 shadow-lg shadow-sky-950"
        >
          {loading ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Play className="w-4 h-4 fill-white" />
          )}
          <span>{loading ? '正在执行三大自检...' : '立即运行确定性自检'}</span>
        </button>
      </div>

      {error && <div className="p-4 bg-rose-950 text-rose-300 text-xs rounded-xl">{error}</div>}

      {!result && !loading && (
        <div className="bg-slate-800/40 border border-slate-700/60 rounded-xl p-8 text-center space-y-3">
          <FileSearch className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="text-base font-semibold text-slate-300">尚未运行自检</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            点击右上角“立即运行确定性自检”按钮，系统将自动对自身的源码、清单引擎以及证据账本进行严格的确定性校验。
          </p>
        </div>
      )}

      {result && (
        <div className="space-y-6">
          {/* 自检概览状态 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 校验项 (a): 违禁词扫描 */}
            <div
              className={`p-5 rounded-xl border flex flex-col justify-between space-y-3 ${
                result.forbiddenScan.passed
                  ? 'bg-emerald-950/30 border-emerald-800/60'
                  : 'bg-rose-950/30 border-rose-800/60'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">源码违禁词检测 (C1, C2)</span>
                {result.forbiddenScan.passed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-400" />
                )}
              </div>
              <div>
                <div className="text-xl font-bold font-mono">
                  {result.forbiddenScan.passed ? '通过 (0 违规)' : `失败 (${result.forbiddenScan.hitCount} 违规)`}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  扫描了 {result.forbiddenScan.scannedFilesCount} 个源码与配置文件
                </div>
              </div>
            </div>

            {/* 校验项 (b): 清单确定性对比 */}
            <div
              className={`p-5 rounded-xl border flex flex-col justify-between space-y-3 ${
                result.inventoryDeterminism.passed
                  ? 'bg-emerald-950/30 border-emerald-800/60'
                  : result.inventoryDeterminism.tested
                  ? 'bg-rose-950/30 border-rose-800/60'
                  : 'bg-slate-900/40 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">清单提取确定性对比 (C5)</span>
                {result.inventoryDeterminism.passed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : result.inventoryDeterminism.tested ? (
                  <XCircle className="w-5 h-5 text-rose-400" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-slate-500" />
                )}
              </div>
              <div>
                <div className="text-xl font-bold font-mono">
                  {result.inventoryDeterminism.passed
                    ? '字节完全一致'
                    : result.inventoryDeterminism.tested
                    ? '哈希不一致'
                    : '未就绪 (无项目)'}
                </div>
                <div className="text-[11px] text-slate-400 mt-1 truncate">
                  {result.inventoryDeterminism.message}
                </div>
              </div>
            </div>

            {/* 校验项 (c): 账本只增不减校验 */}
            <div
              className={`p-5 rounded-xl border flex flex-col justify-between space-y-3 ${
                result.ledgerIntegrity.passed
                  ? 'bg-emerald-950/30 border-emerald-800/60'
                  : 'bg-rose-950/30 border-rose-800/60'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-300">证据账本只增不减校验 (C4, C8)</span>
                {result.ledgerIntegrity.passed ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <XCircle className="w-5 h-5 text-rose-400" />
                )}
              </div>
              <div>
                <div className="text-xl font-bold font-mono">
                  {result.ledgerIntegrity.passed ? '校验通过' : '账本破损'}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  {result.ledgerIntegrity.message}
                </div>
              </div>
            </div>
          </div>

          {/* (a) 违禁词命中细项 */}
          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-5 space-y-3">
            <h3 className="text-sm font-semibold text-slate-200">
              (a) 源码违禁词扫描明细 (Forbidden Pattern Hits)
            </h3>
            {result.forbiddenScan.hits.length === 0 ? (
              <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg text-emerald-300 text-xs font-mono">
                ✓ 自身源码极度干净，未发现任何预置样例、伪造假数据或硬编码特定项目标识！
              </div>
            ) : (
              <div className="space-y-2">
                {result.forbiddenScan.hits.map((hit, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 bg-slate-900 border border-rose-800/60 rounded-lg text-xs font-mono space-y-1"
                  >
                    <div className="flex items-center justify-between text-rose-400">
                      <span>
                        {hit.file}:{hit.line}
                      </span>
                      <span className="px-1.5 py-0.5 bg-rose-950 border border-rose-800 text-[10px] rounded uppercase font-bold">
                        Hit: {hit.keyword}
                      </span>
                    </div>
                    <div className="text-slate-300 bg-slate-950 p-2 rounded text-[11px]">
                      {hit.text}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* (b) 清单确定性对比明细 */}
          {result.inventoryDeterminism.tested && (
            <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-5 space-y-3 font-mono text-xs">
              <h3 className="text-sm font-semibold text-slate-200 font-sans">
                (b) 清单确定性校验细节 (Deterministic Hash Verification)
              </h3>
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-slate-300">
                <div>
                  <span className="text-slate-500">Workspace Hash: </span>
                  <span className="text-sky-300">{result.inventoryDeterminism.workspaceHash}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-sans">第一次提取 JSON 哈希: </span>
                  <span className="text-emerald-400">{result.inventoryDeterminism.run1Hash}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-sans">第二次提取 JSON 哈希: </span>
                  <span className="text-emerald-400">{result.inventoryDeterminism.run2Hash}</span>
                </div>
                <div className="pt-2 text-slate-400 font-sans border-t border-slate-800 text-[11px]">
                  结论: {result.inventoryDeterminism.message}
                </div>
              </div>
            </div>
          )}

          {/* 原始输出 Log */}
          <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-5 space-y-2">
            <h3 className="text-xs font-semibold text-slate-400 font-mono">
              Raw Output Log ({result.timestamp})
            </h3>
            <pre className="p-3 bg-slate-950 text-slate-300 text-[11px] font-mono rounded-lg overflow-x-auto max-h-60">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
