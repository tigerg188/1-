import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { GoogleGenAI } from '@google/genai';
import { SYSTEM_MODELS } from '../config/models.js';
import { getInventory } from './inventory.js';
import { getFeasibilityResult } from './feasibility.js';
import { buildAdaptationPlan } from './adapters.js';
import { appendLedgerEntry } from './ledger.js';

export interface ExecutionStep {
  stepIndex: number;
  timestamp: string;
  stepType: 'user_input' | 'thought' | 'tool_call' | 'model_output' | 'artifact_generated' | 'error';
  toolCalls?: string[];
  truncatedInputOutput: string;
  fullContentHash: string;
  tokensUsed: number;
  error?: string;
}

export interface ArtifactMeta {
  fileName: string;
  relPath: string;
  size: number;
  sha256: string;
  createdAt: string;
}

export interface ExecutionState {
  workspaceHash: string;
  taskText: string;
  testMode: boolean;
  tokenBudget: number;
  tokensUsed: number;
  status: 'running' | 'paused_quota' | 'incomplete' | 'completed' | 'failed';
  statusMessage: string;
  interactionId?: string;
  environmentId?: string;
  steps: ExecutionStep[];
  artifacts: ArtifactMeta[];
  updatedAt: string;
}

const WORKSPACES_DIR = path.resolve(process.cwd(), 'data', 'workspaces');

function getAIClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  return new GoogleGenAI({
    apiKey: apiKey || '',
    httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
  });
}

/**
 * 获取现有任务执行状态
 */
export function getExecutionState(workspaceHash: string): ExecutionState | null {
  const stateFile = path.join(WORKSPACES_DIR, workspaceHash, 'execution_state.json');
  if (fs.existsSync(stateFile)) {
    try {
      return JSON.parse(fs.readFileSync(stateFile, 'utf-8'));
    } catch {}
  }
  return null;
}

export function saveExecutionState(workspaceHash: string, state: ExecutionState) {
  const workspaceDir = path.join(WORKSPACES_DIR, workspaceHash);
  if (!fs.existsSync(workspaceDir)) {
    fs.mkdirSync(workspaceDir, { recursive: true });
  }
  const stateFile = path.join(workspaceDir, 'execution_state.json');
  fs.writeFileSync(stateFile, JSON.stringify(state, null, 2), 'utf-8');
}

/**
 * 指数避退与 429 额度检测包装
 */
async function callAIWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries = 3
): Promise<{ result?: T; quotaExceeded?: boolean; error?: string }> {
  let attempt = 0;
  let delay = 1000;

  while (attempt <= maxRetries) {
    try {
      const res = await fn();
      return { result: res };
    } catch (err: any) {
      const errStr = String(err.message || err);
      const is429 = errStr.includes('429') || errStr.includes('RESOURCE_EXHAUSTED') || errStr.includes('quota');

      if (is429) {
        attempt++;
        if (attempt > maxRetries) {
          return { quotaExceeded: true, error: '额度已用完，进度已保存，可稍后继续' };
        }
        await new Promise((resolve) => setTimeout(resolve, delay));
        delay *= 2; // 指数递增避退
      } else {
        return { error: errStr };
      }
    }
  }

  return { quotaExceeded: true, error: '额度已用完，进度已保存，可稍后继续' };
}

/**
 * 启动或恢复任务执行引擎
 */
export async function startOrResumeTaskExecution(
  workspaceHash: string,
  taskText: string,
  options: { testMode?: boolean; tokenBudget?: number; resume?: boolean }
): Promise<ExecutionState> {
  const workspaceDir = path.join(WORKSPACES_DIR, workspaceHash);
  if (!fs.existsSync(workspaceDir)) {
    throw new Error(`工作空间不存在: ${workspaceHash}`);
  }

  const inventory = getInventory(workspaceHash);
  let feasibility = getFeasibilityResult(workspaceHash);
  if (!feasibility) {
    throw new Error('需先在“适配”页面生成可移植性评估结果');
  }

  const plan = await buildAdaptationPlan(inventory, feasibility);
  let state = getExecutionState(workspaceHash);

  const testMode = options.testMode ?? true;
  const tokenBudget = options.tokenBudget || (testMode ? 10000 : 30000);

  if (!state || !options.resume) {
    state = {
      workspaceHash,
      taskText,
      testMode,
      tokenBudget,
      tokensUsed: 0,
      status: 'running',
      statusMessage: '开始初始化任务执行流程...',
      steps: [],
      artifacts: [],
      updatedAt: new Date().toISOString(),
    };
  } else {
    state.status = 'running';
    state.statusMessage = '恢复任务执行中...';
  }

  saveExecutionState(workspaceHash, state);

  // 写入步骤 1: 用户输入步骤
  const inputHash = crypto.createHash('sha256').update(taskText).digest('hex');
  const userStep: ExecutionStep = {
    stepIndex: state.steps.length + 1,
    timestamp: new Date().toISOString(),
    stepType: 'user_input',
    truncatedInputOutput: taskText.slice(0, 100),
    fullContentHash: inputHash,
    tokensUsed: Math.ceil(taskText.length / 4),
  };
  state.steps.push(userStep);
  state.tokensUsed += userStep.tokensUsed;

  // 保存全文步骤产物文件
  const stepsArtifactsDir = path.join(workspaceDir, 'step_artifacts');
  if (!fs.existsSync(stepsArtifactsDir)) {
    fs.mkdirSync(stepsArtifactsDir, { recursive: true });
  }
  fs.writeFileSync(path.join(stepsArtifactsDir, `step_${userStep.stepIndex}.txt`), taskText, 'utf-8');

  // 追加证据账本记录
  appendLedgerEntry({
    stage: 'STAGE4',
    action: 'EXECUTE_STEP_USER_INPUT',
    inputs_hash: inputHash,
    outputs_hash: inputHash,
    ref: {
      workspace_hash: workspaceHash,
      details: `任务执行开始: 测试模式=${testMode}, Token 预算=${tokenBudget}, 描述="${taskText.slice(0, 30)}..."`,
    },
  });

  const ai = getAIClient();

  // 构建抽象执行 Prompt (遵从 C1 无案例知识，变量代入)
  const systemInstruction = `
你是一个专业的 Agent 任务执行引擎。
请根据用户的任务要求以及选定的后端配置，逐步执行计算与推理。
如果任务需要分析代码或格式，请输出清晰的处理步骤与产出格式。
`;

  const modelInputText = `
【执行任务要求】:
${taskText}

【后端与适配器模式】:
- 选定后端: ${plan.selectedBackend}
- 依赖命令: ${plan.adapters.codeRunAdapter.installCommands.join('; ') || '无额外依赖'}
- 测试模式: ${testMode ? '开启 (限制输出标记与范围)' : '关闭'}
`;

  // 发起模型执行 (带指数避退重试)
  const callResult = await callAIWithBackoff(async () => {
    return await ai.models.generateContent({
      model: SYSTEM_MODELS.DEFAULT_EXECUTION.id,
      contents: modelInputText,
      config: {
        systemInstruction,
        temperature: 0.2,
      },
    });
  });

  if (callResult.quotaExceeded) {
    state.status = 'paused_quota';
    state.statusMessage = callResult.error || '额度已用完，进度已保存，可稍后继续';
    saveExecutionState(workspaceHash, state);
    return state;
  }

  if (callResult.error) {
    state.status = 'failed';
    state.statusMessage = `执行遇到错误: ${callResult.error}`;
    saveExecutionState(workspaceHash, state);
    return state;
  }

  const responseText = callResult.result?.text || '任务计算执行完成';
  const responseHash = crypto.createHash('sha256').update(responseText).digest('hex');
  const tokensEst = Math.ceil(responseText.length / 4);

  // 记录 Model Output 步骤
  const modelStep: ExecutionStep = {
    stepIndex: state.steps.length + 1,
    timestamp: new Date().toISOString(),
    stepType: 'model_output',
    truncatedInputOutput: responseText.slice(0, 150),
    fullContentHash: responseHash,
    tokensUsed: tokensEst,
  };
  state.steps.push(modelStep);
  state.tokensUsed += tokensEst;

  fs.writeFileSync(path.join(stepsArtifactsDir, `step_${modelStep.stepIndex}.txt`), responseText, 'utf-8');

  // 生成收集任务交付物产物 (Artifacts)
  const artifactsDir = path.join(workspaceDir, 'artifacts');
  if (!fs.existsSync(artifactsDir)) {
    fs.mkdirSync(artifactsDir, { recursive: true });
  }

  const outputArtifactName = `output_${Date.now()}.txt`;
  const outputArtifactPath = path.join(artifactsDir, outputArtifactName);
  fs.writeFileSync(outputArtifactPath, responseText, 'utf-8');

  const artifactStat = fs.statSync(outputArtifactPath);
  const artifactMeta: ArtifactMeta = {
    fileName: outputArtifactName,
    relPath: `artifacts/${outputArtifactName}`,
    size: artifactStat.size,
    sha256: responseHash,
    createdAt: new Date().toISOString(),
  };

  state.artifacts.push(artifactMeta);
  state.status = 'completed';
  state.statusMessage = '任务执行已顺畅完成，产出交付物已计算哈希校验';
  state.updatedAt = new Date().toISOString();

  saveExecutionState(workspaceHash, state);

  // 追加证据账本 (Append-only)
  appendLedgerEntry({
    stage: 'STAGE4',
    action: 'EXECUTE_STEP_MODEL_OUTPUT',
    inputs_hash: inputHash,
    outputs_hash: responseHash,
    ref: {
      workspace_hash: workspaceHash,
      file_path: artifactMeta.relPath,
      details: `任务执行完成: Tokens=${state.tokensUsed}/${tokenBudget}, 交付物哈希=${responseHash.slice(0, 16)}...`,
    },
  });

  return state;
}

/**
 * 继续运行 incomplete 状态的任务
 */
export async function continueIncompleteTask(workspaceHash: string): Promise<ExecutionState> {
  const state = getExecutionState(workspaceHash);
  if (!state) {
    throw new Error('未找到任务执行状态');
  }
  return startOrResumeTaskExecution(workspaceHash, state.taskText, {
    testMode: state.testMode,
    tokenBudget: state.tokenBudget,
    resume: true,
  });
}
