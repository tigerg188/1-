# 项目模块与代码路径映射映射表 (PROJECT_MAP.md)

本映射表方便评审者快速定位各功能模块在工程源码中的位置。

## 1. 系统核心与架构

| 功能模块 | 代码文件路径 | 职责说明 |
| :--- | :--- | :--- |
| **硬性宪章** | `/CHARTER.md` | 八条不可违背原则定义 (C1~C8) |
| **模型集中配置** | `/config/models.ts` | 集中集中放置模型与 Agent ID (C6 配额友好) |
| **服务器入口** | `/server.ts` | Express API 服务路由与 Vite 中间件 |
| **全套数据模型** | `/src/types.ts` | 跨前后端 TypeScript 接口类型定义 |
| **UI 壳层** | `/src/App.tsx` | 符合 Top Bar Contract 的主导航与页签控制 |

---

## 2. 阶段 1: 运行时导入、确定性清单与证据账本

| 功能模块 | 代码文件路径 | 职责说明 |
| :--- | :--- | :--- |
| **运行时项目导入** | `/server/ingest.ts` | GitHub Zipball 下载与安全解压校验 |
| **导入 UI 界面** | `/src/pages/ImportPage.tsx` | GitHub URL 与 Zip 拖拽上传 |
| **确定性清单引擎** | `/server/inventory.ts` | 纯代码提取文件树、格式矩阵、标题与步骤行 (NO model) |
| **清单 UI 界面** | `/src/pages/InventoryPage.tsx` | 清单分层展示与 raw inventory.json 视图 |
| **证据账本** | `/server/ledger.ts` | Append-only JSONL 读写与完整性校验 |
| **账本 UI 界面** | `/src/pages/LedgerPage.tsx` | 账本表格检索与 `ledger.jsonl` 导出 |
| **确定性自检引擎** | `/server/selftest.ts` | 三大确定性自检 (违禁词扫描、清单确定性、账本只增不减) |
| **自检 UI 界面** | `/src/pages/SelfTestPage.tsx` | 交互式触发自检与日志透视 |

---

## 3. 阶段 2: 蓝图理解与结构提取引擎 (Blueprint)

| 功能模块 | 代码文件路径 | 职责说明 |
| :--- | :--- | :--- |
| **抽象提示词模板** | `/server/prompts.ts` | 使用 `<UNIT_PATH>` 抽象变量，无案例知识 (C1) |
| **蓝图理解引擎** | `/server/understand.ts` | L0~L3 分层蓝图合成、对账报告、强证据校验器与反例检索 |
| **显式证据标签** | `/src/components/EvidenceTagBadge.tsx` | `[证据 file:line "quote"]` 与 `[推断]` 标签 |
| **蓝图 UI 界面** | `/src/pages/BlueprintPage.tsx` | L0~L3 选项卡、SVG 拓扑图、Mermaid 语法导出与对账面板 |

---

## 4. 阶段 3: 平台可移植性判定与适配引擎

| 功能模块 | 代码文件路径 | 职责说明 |
| :--- | :--- | :--- |
| **声明式能力字典** | `/server/feasibility.ts` | 13 项能力定义与状态持久化 (`capability_model.json`) |
| **实时探针引擎** | `/server/feasibility.ts` | 极小 Token 探针测试并写回能力字典 |
| **可移植性判定** | `/server/feasibility.ts` | 纯代码匹配算出的逐单元 Verdict、整包 Verdict 与损失列表 |
| **统一执行后端** | `/server/adapters.ts` | `ExecutionBackend` 统一接口、托管沙盒与纯 LLM 后端 |
| **格式特征适配器** | `/server/adapters.ts` | 指令文件适配、代码运行适配与改写计划书 |
| **DRY-RUN 校验器** | `/server/adapters.ts` | Config JSON 生成、容量检查与明文密钥安全审计 |
| **适配 UI 界面** | `/src/pages/AdaptersPage.tsx` | 能力拓扑表格、探针触发按键与 DRY-RUN 校验结果 |

---

## 5. 阶段 4: 任务执行、独立双路验证与报告导出

| 功能模块 | 代码文件路径 | 职责说明 |
| :--- | :--- | :--- |
| **任务执行引擎** | `/server/execute.ts` | 描述运行、Token 预算限制、步骤打卡、产物哈希与 429 重试恢复 |
| **执行 UI 界面** | `/src/pages/ExecutePage.tsx` | Live Token 仪表条与打卡步骤终端 |
| **独立双路验证器** | `/server/verify.ts` | 专属 System Prompt，彻底排除执行器思考，Payload 写盘审计 |
| **验证 UI 界面** | `/src/pages/VerifyPage.tsx` | 预推导标准、代码强校验、逐条判决表格与 Payload 透视 |
| **综合评估报告导出** | `/server/report.ts` | Markdown, HTML, JSON 及 ZIP 档案全量导出 |

---

## 6. 验收与测试套件

| 功能模块 | 代码文件路径 | 职责说明 |
| :--- | :--- | :--- |
| **验收自动化测试套件** | `/acceptance/runner.ts` | 机械化运行 A0 ~ A16 验收测试并导出 JSON 日志 |
| **验收报告** | `/ACCEPTANCE_REPORT.md` | 全量验收测试表格与自评分析报告 |
