import express from 'express';
import path from 'path';
import fs from 'fs';
import multer from 'multer';
import { createServer as createViteServer } from 'vite';
import { ingestGithubRepo, processZipBuffer } from './server/ingest.js';
import { getInventory } from './server/inventory.js';
import { readLedgerEntries, checkLedgerIntegrity } from './server/ledger.js';
import { runSelfTest } from './server/selftest.js';
import { getBlueprint, analyzeBlueprintPipeline } from './server/understand.js';
import {
  getCapabilityModel,
  runCapabilityProbe,
  runAllCapabilityProbes,
  evaluateFeasibilityPipeline,
  getFeasibilityResult,
} from './server/feasibility.js';
import { runDryRunValidator } from './server/adapters.js';
import {
  startOrResumeTaskExecution,
  getExecutionState,
  continueIncompleteTask,
} from './server/execute.js';
import {
  deriveVerificationCriteria,
  runIndependentVerificationEngine,
  getVerificationReport,
} from './server/verify.js';
import {
  generateFullReportData,
  generateMarkdownReport,
  generateHtmlReport,
  createReportZipBuffer,
} from './server/report.js';

const upload = multer({
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // API Routes
  
  // 1. 获取宪章与构建日志
  app.get('/api/charter', (req, res) => {
    const charterPath = path.resolve(process.cwd(), 'CHARTER.md');
    if (fs.existsSync(charterPath)) {
      res.type('text/plain').send(fs.readFileSync(charterPath, 'utf-8'));
    } else {
      res.status(404).json({ error: 'CHARTER.md 未找到' });
    }
  });

  app.get('/api/build-log', (req, res) => {
    const logPath = path.resolve(process.cwd(), 'BUILD_LOG.md');
    if (fs.existsSync(logPath)) {
      res.type('text/plain').send(fs.readFileSync(logPath, 'utf-8'));
    } else {
      res.status(404).json({ error: 'BUILD_LOG.md 未找到' });
    }
  });

  // 2. 运行时导入接口 (GitHub / Zip)
  app.post('/api/ingest/github', async (req, res) => {
    try {
      const { repoUrl } = req.body;
      if (!repoUrl) {
        return res.status(400).json({ error: '请输入有效的 GitHub 仓库地址' });
      }
      const result = await ingestGithubRepo(repoUrl);
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || 'GitHub 导入失败' });
    }
  });

  app.post('/api/ingest/zip', upload.single('file'), (req, res) => {
    try {
      if (!req.file || !req.file.buffer) {
        return res.status(400).json({ error: '请上传有效的 .zip 压缩文件' });
      }
      const result = processZipBuffer(req.file.buffer, 'zip');
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || 'Zip 解压导入失败' });
    }
  });

  // 2.5 获取当前/最近激活的工作空间
  app.get('/api/workspaces/current', (req, res) => {
    try {
      const workspacesDir = path.resolve(process.cwd(), 'data', 'workspaces');
      if (!fs.existsSync(workspacesDir)) {
        return res.json({ success: true, data: null });
      }
      const dirs = fs.readdirSync(workspacesDir).filter((d) => !d.startsWith('.'));
      if (dirs.length === 0) {
        return res.json({ success: true, data: null });
      }
      dirs.sort((a, b) => {
        const statA = fs.statSync(path.join(workspacesDir, a));
        const statB = fs.statSync(path.join(workspacesDir, b));
        return statB.mtimeMs - statA.mtimeMs;
      });
      const latestHash = dirs[0];
      const metaPath = path.join(workspacesDir, latestHash, '.ingest_meta.json');
      if (fs.existsSync(metaPath)) {
        const meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
        return res.json({ success: true, data: meta });
      }
      res.json({ success: true, data: { workspaceHash: latestHash } });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // 3. 确定性清单接口
  app.get('/api/inventory/:hash', (req, res) => {
    try {
      const { hash } = req.params;
      const data = getInventory(hash);
      res.json({ success: true, data });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || '获取清单失败' });
    }
  });

  // 4. 证据账本接口
  app.get('/api/ledger', (req, res) => {
    try {
      const entries = readLedgerEntries();
      const integrity = checkLedgerIntegrity();
      res.json({ success: true, entries, integrity });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || '读取证据账本失败' });
    }
  });

  app.get('/api/ledger/export', (req, res) => {
    try {
      const ledgerPath = path.resolve(process.cwd(), 'data', 'ledger.jsonl');
      if (fs.existsSync(ledgerPath)) {
        res.setHeader('Content-Type', 'application/x-jsonlines');
        res.setHeader('Content-Disposition', 'attachment; filename="ledger.jsonl"');
        res.sendFile(ledgerPath);
      } else {
        res.status(404).send('账本尚无记录');
      }
    } catch (err: any) {
      res.status(500).send('导出失败: ' + err.message);
    }
  });

  // 5. 确定性自检接口
  app.post('/api/selftest', (req, res) => {
    try {
      const { workspaceHash } = req.body;
      const result = runSelfTest(workspaceHash);
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || '执行自检失败' });
    }
  });

  // 3.5 蓝图理解引擎接口 (Stage 2)
  app.get('/api/blueprint/:hash', (req, res) => {
    try {
      const { hash } = req.params;
      const bp = getBlueprint(hash);
      if (bp) {
        res.json({ success: true, data: bp });
      } else {
        res.json({ success: false, data: null, message: '尚未生成蓝图，请发起分析' });
      }
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || '获取蓝图失败' });
    }
  });

  app.post('/api/blueprint/analyze', async (req, res) => {
    try {
      const { workspaceHash } = req.body;
      if (!workspaceHash) {
        return res.status(400).json({ error: '缺失工作空间 Hash' });
      }
      const inventory = getInventory(workspaceHash);
      const blueprint = await analyzeBlueprintPipeline(workspaceHash, inventory);
      res.json({ success: true, data: blueprint });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || '生成蓝图过程出错' });
    }
  });

  // 3.8 平台能力字典与探针接口 (Stage 3)
  app.get('/api/feasibility/capability-model', (req, res) => {
    try {
      const model = getCapabilityModel();
      res.json({ success: true, data: model });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post('/api/feasibility/probe', async (req, res) => {
    try {
      const { key } = req.body;
      if (key) {
        const updated = await runCapabilityProbe(key);
        res.json({ success: true, data: updated, model: getCapabilityModel() });
      } else {
        const model = await runAllCapabilityProbes();
        res.json({ success: true, data: model, model });
      }
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || '运行探针遇到错误' });
    }
  });

  app.post('/api/feasibility/evaluate', async (req, res) => {
    try {
      const { workspaceHash } = req.body;
      if (!workspaceHash) {
        return res.status(400).json({ error: '缺失工作空间 Hash' });
      }
      const inventory = getInventory(workspaceHash);
      const result = await evaluateFeasibilityPipeline(workspaceHash, inventory);
      res.json({ success: true, data: result });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || '可移植性评估失败' });
    }
  });

  app.get('/api/feasibility/result/:hash', (req, res) => {
    try {
      const { hash } = req.params;
      const resData = getFeasibilityResult(hash);
      if (resData) {
        res.json({ success: true, data: resData });
      } else {
        res.json({ success: false, data: null, message: '尚未运行评估' });
      }
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post('/api/adapters/dry-run', async (req, res) => {
    try {
      const { workspaceHash } = req.body;
      if (!workspaceHash) {
        return res.status(400).json({ error: '缺失工作空间 Hash' });
      }
      const inventory = getInventory(workspaceHash);
      let feasibility = getFeasibilityResult(workspaceHash);
      if (!feasibility) {
        feasibility = await evaluateFeasibilityPipeline(workspaceHash, inventory);
      }
      const dryRunRes = await runDryRunValidator(workspaceHash, inventory, feasibility);
      res.json({ success: true, data: dryRunRes });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || 'DRY-RUN 校验失败' });
    }
  });

  // 4.0 任务执行引擎接口 (Stage 4)
  app.post('/api/execute/start', async (req, res) => {
    try {
      const { workspaceHash, taskText, testMode, tokenBudget } = req.body;
      if (!workspaceHash || !taskText) {
        return res.status(400).json({ error: '缺失工作空间 Hash 或任务描述' });
      }
      const state = await startOrResumeTaskExecution(workspaceHash, taskText, {
        testMode,
        tokenBudget,
        resume: false,
      });
      res.json({ success: true, data: state });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || '启动任务执行失败' });
    }
  });

  app.get('/api/execute/status/:hash', (req, res) => {
    try {
      const { hash } = req.params;
      const state = getExecutionState(hash);
      res.json({ success: true, data: state });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post('/api/execute/continue', async (req, res) => {
    try {
      const { workspaceHash } = req.body;
      if (!workspaceHash) {
        return res.status(400).json({ error: '缺失工作空间 Hash' });
      }
      const state = await continueIncompleteTask(workspaceHash);
      res.json({ success: true, data: state });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || '继续运行任务失败' });
    }
  });

  // 4.5 独立双路验证与比对接口 (Stage 4)
  app.post('/api/verify/criteria', (req, res) => {
    try {
      const { workspaceHash, taskText } = req.body;
      const blueprint = getBlueprint(workspaceHash);
      const criteria = deriveVerificationCriteria(blueprint, taskText || '未指定任务文本');
      res.json({ success: true, data: criteria });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.post('/api/verify/run', async (req, res) => {
    try {
      const { workspaceHash, taskText } = req.body;
      if (!workspaceHash) {
        return res.status(400).json({ error: '缺失工作空间 Hash' });
      }
      const report = await runIndependentVerificationEngine(workspaceHash, taskText || '标准验收任务');
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message || '独立验证过程出错' });
    }
  });

  app.get('/api/verify/result/:hash', (req, res) => {
    try {
      const { hash } = req.params;
      const report = getVerificationReport(hash);
      res.json({ success: true, data: report });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // 4.8 综合评估报告导出接口 (Stage 4)
  app.get('/api/report/export/:hash/:format', (req, res) => {
    try {
      const { hash, format } = req.params;
      if (format === 'json') {
        const data = generateFullReportData(hash);
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', `attachment; filename="report_${hash.slice(0, 8)}.json"`);
        res.send(JSON.stringify(data, null, 2));
      } else if (format === 'md') {
        const mdText = generateMarkdownReport(hash);
        res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
        res.setHeader('Content-Disposition', `attachment; filename="report_${hash.slice(0, 8)}.md"`);
        res.send(mdText);
      } else if (format === 'html') {
        const htmlText = generateHtmlReport(hash);
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.setHeader('Content-Disposition', `attachment; filename="report_${hash.slice(0, 8)}.html"`);
        res.send(htmlText);
      } else if (format === 'zip') {
        const zipBuf = createReportZipBuffer(hash);
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', `attachment; filename="audit_bundle_${hash.slice(0, 8)}.zip"`);
        res.send(zipBuf);
      } else {
        res.status(400).send('不支持的导出格式');
      }
    } catch (err: any) {
      res.status(500).send('导出失败: ' + err.message);
    }
  });

  // API 404 Fallback - Prevent returning HTML for unhandled API endpoints
  app.all('/api/*', (req, res) => {
    res.status(404).json({ success: false, error: `API 接口未找到 (404): ${req.method} ${req.path}` });
  });

  // Vite middle-wares in dev mode
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);
    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = fs.readFileSync(path.resolve(process.cwd(), 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    // Static production serve
    app.use(express.static(path.resolve(process.cwd(), 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(process.cwd(), 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Server] Express 引擎启动于端口 http://0.0.0.0:${PORT}`);
  });
}

startServer();
