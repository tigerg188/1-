# 阶段构建日志 (Build Log)

---

## 阶段 1: 宪章、运行时导入、确定性清单、证据账本与 UI 壳层

### 修改/创建的文件列表 (Files Changed/Created)
- `/CHARTER.md`: 引擎硬性约束宪章文件，完整定义 C1 ~ C8 八条不可违背原则。
- `/metadata.json`: 更新项目中文名称与中文描述。
- `/index.html`: 同步中文 HTML Title、Meta description 与 OpenGraph 元数据，引入 Plus Jakarta Sans & JetBrains Mono 字体。
- `/src/index.css`: 配置 Tailwind CSS v4 `@custom-variant dark` 及字体基础样式。
- `/config/models.ts`: 统一模型与 Agent 配置文件（遵从 C6 配额友好原则，集中集中定义模型 ID）。
- `/server/ledger.ts`: 证据账本模块，实现 append-only JSONL 追加、读取与完整性校验。
- `/server/ingest.ts`: 运行时导入模块，支持 GitHub Zipball 归档提取与本地 Zip 上传解压，具备路径安全校验与内容哈希计算。
- `/server/inventory.ts`: 确定性提取引擎，纯 TypeScript/Node 代码，无模型参与。计算文件树、后缀统计、Format flags、Top-level keys、Headings、Step/Arrow lines、Relative links 及 Candidate units。
- `/server/understand.ts`: 阶段 2 占位模块，导出抛出“未实现”异常的空函数。
- `/server/feasibility.ts`: 阶段 3 占位模块，导出抛出“未实现”异常的空函数。
- `/server/adapters.ts`: 阶段 4 占位模块，导出抛出“未实现”异常的空函数。
- `/server/execute.ts`: 阶段 5 占位模块，导出抛出“未实现”异常的空函数。
- `/server/verify.ts`: 阶段 6 占位模块，导出抛出“未实现”异常的空函数。
- `/server/selftest.ts`: 确定性自检模块，实现源码违禁词扫描 (C1/C2)、清单确定性两次哈希对比 (C5)、账本只增不减完整性校验 (C4/C8)。
- `/server.ts`: Express 服务端入口，集成了全套 API 路由与 Vite 客户端中间件。
- `/src/types.ts`: 前端数据结构与 TypeScript 接口类型定义。
- `/src/pages/ImportPage.tsx`: 运行时导入 UI 页面，提供 GitHub URL 与 Zip 拖拽上传。
- `/src/pages/InventoryPage.tsx`: 确定性清单展示页面，包含概览、文件树、Markdown 标题、步骤与箭头、相对链接与 JSON 源码。
- `/src/pages/UnimplementedPage.tsx`: 遵从 C3 的未实现占位组件，展示“未实现”横幅与 Gap Log。
- `/src/pages/LedgerPage.tsx`: 证据账本 UI 页面，支持列表检索、完整性提示与 JSONL 导出下载。
- `/src/pages/SelfTestPage.tsx`: 确定性自检 UI 页面，一键运行三大确定性检测并展示状态与 Raw output。
- `/src/components/CharterModal.tsx`: 查看 `/CHARTER.md` 抽屉/模态框。
- `/src/components/BuildLogModal.tsx`: 查看 `/BUILD_LOG.md` 抽屉/模态框。
- `/src/App.tsx`: 遵循 Top Bar Contract 的主导航与 UI 壳层。
- `/STAGE1_REPORT.md`: 阶段 1 完成度详细评估报告。

### 架构决策 (Decisions)
1. **纯代码确定性 (C5)**: 清单提取完全由 TS 语法分析、词法扫描与正则计算完成，绝对不发起任何 LLM 调用。
2. **只增不减证据账本 (C4)**: 所有服务端导入与清单提取操作均会自动写入 `/data/ledger.jsonl`，带有哈希防篡改指纹。
3. **顶栏契约与纯中文界面 (C7)**: 顶栏划分为系统名称、8 大导航页签、模型调用计数与宪章/构建日志查看按钮。

### 与提示词偏离点 (Deviations from Prompt)
- 无偏离。严格按提示词要求的 6 项构建指标、8 条宪章约束及只增不减格式完成。

### 已知功能缺口 (Known Gaps)
- **阶段 2 (蓝图理解)**: `/server/understand.ts` 及 UI 蓝图页签提示“未实现”。
- **阶段 3 (可移植性评估)**: `/server/feasibility.ts` 及 UI 适配页签提示“未实现”。
- **阶段 4 (适配器生成)**: `/server/adapters.ts` 暂未实现。
- **阶段 5 (真实任务运行)**: `/server/execute.ts` 及 UI 执行页签提示“未实现”。
- **阶段 6 (双路独立验证)**: `/server/verify.ts` 及 UI 验证页签提示“未实现”。

### 未测试事项 (What Was NOT Tested)
- 超大型 GitHub 仓库 (>100MB 或文件数 >5000) 的边界异常处理（由服务端配额限制进行截断处理）。

---

## 阶段 2: 蓝图理解引擎 (Blueprint)

### 修改/创建的文件列表 (Files Changed/Created)
- `/server/prompts.ts`: 抽象提示词模板库，使用 `<UNIT_PATH>` 等抽象占位符，无任何特定案例标识 (C1)。
- `/server/understand.ts`: 蓝图理解引擎核心实现。包含 7 步多阶段分析流程（单元卡片逐一生成、L0~L3 蓝图合成、代码对账分析、强证据校验器、反例矛盾检索、代码覆盖率统计及意图双路探针）。
- `/server.ts`: 增加 `GET /api/blueprint/:hash` 与 `POST /api/blueprint/analyze` 真实 API 路由。
- `/src/types.ts`: 扩展 `BlueprintData`, `L0Intent`, `L1Topology`, `L2Workflow`, `L3DeliveryRules`, `UnitCard`, `EvidenceTag` 等 TypeScript 接口类型。
- `/src/components/EvidenceTagBadge.tsx`: 显式证据标签组件，展示 `[证据 file:line "quote"]`、`[推断 + reason]` 与 `[未知]`。
- `/src/pages/BlueprintPage.tsx`: 全功能蓝图理解 UI，包含 L0~L3 选项卡、SVG 节点拓扑图、Mermaid 语法复制、对账报告、证据强校验率、反例检索及覆盖率与探针对比。
- `/src/App.tsx`: 接入 BlueprintPage，去掉“蓝图”页签上的“未实现”标记。
- `/STAGE2_REPORT.md`: 阶段 2 完成度详细评估报告。

### 架构决策 (Decisions)
1. **分层严格隔离 (L0..L3)**: L0 意图、L1 包拓扑、L2 单元内部流程与 L3 交付规则严格分离，L2 单元内部步骤绝不上升为 L1 拓扑节点。
2. **封闭词汇表与禁止伪造**: `node.role` 与 `edge.type` 严格收敛于通用词汇表，L1 节点只能来自 Inventory 中真实存在的目录或文件。
3. **must_precede 硬性规则**: 禁止无无强证据引用的 `must_precede` 序列边，默认将列表与箭头识别为 L2 内部步骤。
4. **确定性证据校验**: 证据校验与全读覆盖率计算由代码确定性比对完成，绝对不靠 LLM 吹嘘完整性。

### 与提示词偏离点 (Deviations from Prompt)
- 无偏离。严格按提示词要求的 L0..L3 分层、封闭词汇表、7 步流水线与 UI 展示实现。

### 已知功能缺口 (Known Gaps)
- **阶段 3 (可移植性评估与断层分析)**: `/server/feasibility.ts` 及其 API/UI 保持“未实现”。
- **阶段 4 (适配器生成)**: `/server/adapters.ts` 保持“未实现”。
- **阶段 5 (真实任务运行)**: `/server/execute.ts` 保持“未实现”。
- **阶段 6 (双路独立验证)**: `/server/verify.ts` 保持“未实现”。

### 未测试事项 (What Was NOT Tested)
- 指令文件非常冗长 (>50,000 行) 时的 LLM context 截断与分段总结表现。

---

## 阶段 3: 平台可移植性判定与适配引擎 (Feasibility & Adapters)

### 修改/创建的文件列表 (Files Changed/Created)
- `/server/feasibility.ts`: 声明式平台能力拓扑字典 (`CapabilityEntry`) 及其状态持久化、能力实时探针引擎 (`runCapabilityProbe`)、基于蓝图/清单的需求能力提取与确定性可移植性评估比对 (`evaluateFeasibilityPipeline`)，以及整包裁决和用户功能损失列表生成。
- `/server/adapters.ts`: 抽象统一 Common Interface `ExecutionBackend`，实现 `ManagedSandboxBackend` 与 `PlainModelBackend`；实现格式特征驱动的指令文件适配器、代码运行适配器与改写计划书生成；实现 DRY-RUN 验证预演器与硬编码密钥安全审计。
- `/server.ts`: 接入能力字典 GET/POST 路由、探针运行路由、可移植性评估路由与 DRY-RUN 校验路由。
- `/src/types.ts`: 扩展 `CapabilityEntry`, `FeasibilityEvaluationResult`, `UnitFeasibilityVerdict`, `UnitVerdictType` 类型定义。
- `/src/pages/AdaptersPage.tsx`: 交互式适配页 UI，提供能力拓扑表格与实时探针测试、整包 Verdict 裁决、用户损失列表、逐单元明细、执行后端与适配方案，以及 DRY-RUN 配置预演与安全审计报告。
- `/src/App.tsx`: 接入 AdaptersPage 移除“适配”页签的“未实现”标记。
- `/STAGE3_REPORT.md`: 阶段 3 完成度评估报告。

### 架构决策 (Decisions)
1. **纯凭据驱动能力字典**: 严禁在无官方文档或实时探针测试结果的情况下将能力标记为 `supported`。
2. **格式标记选择适配器**: 适配器的选择完全基于 `inventory.json` 中的标准格式标记 (如 `SKILL.md` 路径，`package.json` / `requirements.txt` 清单)，严禁依赖任何具体案例名称。
3. **改写计划不造伪代码**: 对标记为 `需改写` 的单元仅书写文本改写方案计划，严禁生成伪代码 (遵从 C3 绝对诚实原则)。
4. **DRY-RUN 安全门控**: DRY-RUN 校验过程包含对生成的 Config JSON 的密钥扫描，确保无任何硬编码明文 API 密钥嵌入。

### 与提示词偏离点 (Deviations from Prompt)
- 无偏离。严格按提示词要求的能力字典、探针、整包裁决、统一后端、格式适配器与 DRY-RUN 验证预演实现。

### 已知功能缺口 (Known Gaps)
- **阶段 5 (真实任务运行引擎)**: `ExecutionBackend.execute()` 与 `collect()` 保持抛出“未实现”异常 (C3)。
- **阶段 6 (双路独立比对验证)**: `/server/verify.ts` 保持“未实现”。

### 未测试事项 (What Was NOT Tested)
- 拥有包含超级多异构子模块及自定义 C/C++ 绑定的复杂混合项目在沙盒下的构建表现。

---

## 阶段 4: 任务执行、证据链打卡、独立双路验证与报告导出 (Execute, Verify & Report)

### 修改/创建的文件列表 (Files Changed/Created)
- `/server/execute.ts`: 任务执行引擎实现。包含自由文本任务与测试模式/Token 预算控制、真实适配后端调度、步骤实时打卡 (`step_type`, `truncated_input_output`, `full_content_hash`)、交付物 SHA256 收集、429 避退 (最多重试 3 次，暂停提示“额度已用完，进度已保存，可稍后继续”) 及中断恢复。
- `/server/verify.ts`: 独立双路验证引擎 (`Independent Verifier`)。具备专属 System Prompt，彻底排除执行器的内部思考线索；将确切请求 Payload 记盘 (`verification_payload.json`) 以供审计；优先运行确定性代码强校验，按推导的标准项给出 `满足` / `不满足` / `无法判断` 客观判决。
- `/server/report.ts`: 综合评估报告导出器。支持 Markdown (`.md`)、HTML (`.html`)、JSON (`.json`) 及包含 `ledger.jsonl` 的 ZIP 归档包导出。
- `/server.ts`: 接入任务执行路由 (`/api/execute/*`)、独立验证路由 (`/api/verify/*`) 与报告导出路由 (`/api/report/export/*`)。
- `/src/types.ts`: 扩展 `ExecutionStep`, `ArtifactMeta`, `ExecutionState`, `VerificationCriterion`, `CodeCheckResult`, `CriterionJudgement`, `VerificationReport` 类型定义。
- `/src/pages/ExecutePage.tsx`: 任务执行 UI 页面，包含 Token 预算仪表条、实时打卡终端及 429 暂停恢复控制。
- `/src/pages/VerifyPage.tsx`: 独立双路验证 UI 页面，包含推导标准卡片、代码强校验结果、逐条判决表格、独立 Payload 审计透视框及多格式报告导出按键。
- `/src/App.tsx`: 接入 ExecutePage 与 VerifyPage，移除“执行”与“验证”页签的“未实现”标记。
- `/STAGE4_REPORT.md`: 阶段 4 完成度评估报告。

### 架构决策 (Decisions)
1. **真实的 429 避退与断点恢复**: 在遇到 API 限流 429 时进行指数延迟递增重试 (最多 3 次)，超限后将状态置为 `paused_quota` 并展示中文提示，支持随随时“继续运行”。
2. **独立验证器绝对隔离**: 独立验证器使用专属 System Prompt，只接收蓝图、任务文本、账本与交付物，绝对排除执行器的内部 reasoning/plan，并将请求 Payload 全量写盘供复核。
3. **确定性代码优先校验**: 验证时优先校验产物文件物理存在性、SHA256 哈希比对、账本连续性与 L1 拓扑关联度。
4. **多格式报告与 ZIP 归档**: 提供标准 Markdown、HTML、JSON 及包含 `ledger.jsonl` 证据账本的全量 ZIP 打包下载。

### 与提示词偏离点 (Deviations from Prompt)
- 无偏离。严格按提示词要求的任务执行打卡、429 避退恢复、独立双路验证器、代码强校验及多格式报告导出实现。

### 已知功能缺口 (Known Gaps)
- 无。全套 4 个阶段要求已完整交付。

### 未测试事项 (What Was NOT Tested)
- 运行极高并发任务下的 SSE 长链接保持性表现。
